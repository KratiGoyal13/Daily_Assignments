
import os

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver

from tools import search_restaurants, calculate_dining_cost

from guardrails import (
    validate_input,
    detect_pii,
    redact_pii,
    is_restaurant_related
)

load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

# Conversation memory
memory = InMemorySaver()

# Initialize agent only when an API key exists
agent = None

if api_key:

    model = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0,
        api_key=api_key
    )

    SYSTEM_PROMPT = """
    You are a professional AI Restaurant Assistant.

    Responsibilities:
    1. Search restaurants.
    2. Calculate estimated dining costs.
    3. Remember selected restaurants.
    4. Remember guest counts.
    5. Handle contextual follow-up questions.

    Rules:
    - Only answer restaurant-related questions.
    - Use Python tools for restaurant information.
    - Never invent restaurant names.
    - Never invent prices or available seats.
    - Use only actual tool results.
    - Never claim a reservation was booked.
    - Never process payments.
    - Guest count must be between 1 and 20.
    - Remember the previously selected restaurant.
    - For follow-up guest changes, use the previous
      restaurant ID if it is unambiguous.
    - Clearly label cost calculations as estimates.
    """

    agent = create_agent(
        model=model,
        tools=[
            search_restaurants,
            calculate_dining_cost
        ],
        system_prompt=SYSTEM_PROMPT,
        checkpointer=memory
    )


def run_agent(message, thread_id):

    valid, error_message = validate_input(message)

    if not valid:
        return {
            "ok": False,
            "response": error_message,
            "tool_calls": [],
            "guardrail": "Input validation"
        }

    if detect_pii(message):
        return {
            "ok": False,
            "response": (
                "Personal information detected. "
                "Please do not share email addresses or phone numbers.\n\n"
                + redact_pii(message)
            ),
            "tool_calls": [],
            "guardrail": "PII detection"
        }

    if agent is None:
        return {
            "ok": False,
            "response": "OpenAI API key is not configured.",
            "tool_calls": [],
            "guardrail": "API configuration"
        }

    config = {
        "configurable": {
            "thread_id": thread_id
        }
    }

    try:

        state = agent.get_state(config)

        has_history = bool(
            state.values.get("messages", [])
        )

        if not is_restaurant_related(message, has_history):
            return {
                "ok": False,
                "response": (
                    "I can only help with restaurant-related questions."
                ),
                "tool_calls": [],
                "guardrail": "Domain restriction"
            }

        result = agent.invoke(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": message
                    }
                ]
            },
            config=config
        )

        # Collect tool execution details
        tool_calls = []

        for msg in result["messages"]:

            for call in getattr(msg, "tool_calls", []):
                tool_calls.append({
                    "name": call["name"],
                    "arguments": call["args"]
                })

        # Extract final response
        response = result["messages"][-1].content

        if isinstance(response, list):
            response = " ".join(
                item.get("text", "")
                for item in response
                if isinstance(item, dict)
            )

        response = redact_pii(str(response))

        return {
            "ok": True,
            "response": response,
            "tool_calls": tool_calls,
            "guardrail": None
        }

    except Exception as error:

        error_text = str(error).lower()

        if "429" in error_text or "no credits" in error_text:
            response = (
                "OpenAI API credits are currently unavailable. "
                "Please try again after credits are allotted."
            )
        else:
            response = "Unable to process your request. Please try again."

        return {
            "ok": False,
            "response": response,
            "tool_calls": [],
            "guardrail": "API error"
        }
