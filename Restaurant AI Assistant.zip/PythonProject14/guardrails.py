
import re

EMAIL_PATTERN = (
    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'
)

PHONE_PATTERN = (
    r'(?<!\w)(?:\+?\d[\d\s()-]{8,16}\d)(?!\w)'
)


def validate_input(message):

    if not message or not message.strip():
        return False, "Question cannot be empty."

    if len(message) > 500:
        return False, "Maximum 500 characters allowed."

    return True, "Valid input."


def detect_pii(message):

    emails = re.findall(EMAIL_PATTERN, message)
    phones = re.findall(PHONE_PATTERN, message)

    return bool(emails or phones)


def redact_pii(message):

    message = re.sub(
        EMAIL_PATTERN,
        "[EMAIL REDACTED]",
        message
    )

    message = re.sub(
        PHONE_PATTERN,
        "[PHONE REDACTED]",
        message
    )

    return message


def is_restaurant_related(message, has_history=False):

    text = message.lower().strip()

    followups = [
        "yes", "no", "okay", "ok",
        "sure", "that one", "same",
        "make that", "what about",
        "increase it", "decrease it"
    ]

    if has_history:
        if text.isdigit():
            return True

        if any(text.startswith(x) for x in followups):
            return True

        if re.search(
            r'\b\d+\s*(people|guests|persons)\b',
            text
        ):
            return True

    keywords = [
        "restaurant", "restaurants",
        "food", "dining", "dinner",
        "lunch", "breakfast", "cuisine",
        "indian", "italian", "chinese",
        "mexican", "spice garden",
        "olive bistro", "dragon palace",
        "tandoori tales", "pasta paradise",
        "price", "cost", "guest", "guests",
        "seats", "availability", "reservation",
        "calculate", "search", "show me"
    ]

    return any(word in text for word in keywords)
