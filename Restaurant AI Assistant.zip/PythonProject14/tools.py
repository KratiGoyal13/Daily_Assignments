
import json
from pathlib import Path
from langchain.tools import tool

DATA_FILE = Path(__file__).parent / "restaurants.json"


def load_restaurants():
    with open(DATA_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


@tool
def search_restaurants(keyword: str) -> str:
    """Search restaurants by cuisine, restaurant name or location."""

    keyword = keyword.strip().lower()

    if not keyword:
        return "Please enter a restaurant name, cuisine or location."

    restaurants = load_restaurants()
    matches = []

    for restaurant in restaurants:
        if (
            keyword in restaurant["name"].lower()
            or keyword in restaurant["cuisine"].lower()
            or keyword in restaurant["location"].lower()
        ):
            matches.append(restaurant)

    if not matches:
        return f"No restaurants found for {keyword}."

    results = []

    for r in matches:
        results.append(
            f"ID: {r['id']}\n"
            f"Restaurant: {r['name']}\n"
            f"Cuisine: {r['cuisine']}\n"
            f"Location: {r['location']}\n"
            f"Price per person: Rs. {r['price_per_person']}\n"
            f"Available seats: {r['available_seats']}"
        )

    return "\n\n".join(results)


@tool
def calculate_dining_cost(
    restaurant_id: str,
    guests: int
) -> str:
    """Calculate estimated dining cost for 1 to 20 guests."""

    if isinstance(guests, bool) or not isinstance(guests, int):
        return "Invalid guest count. Enter a whole number."

    if guests < 1 or guests > 20:
        return "Invalid guest count. Please enter between 1 and 20."

    restaurants = load_restaurants()

    selected = next(
        (
            r for r in restaurants
            if r["id"].lower() == restaurant_id.strip().lower()
        ),
        None
    )

    if selected is None:
        return f"Restaurant {restaurant_id} does not exist."

    price = selected["price_per_person"]
    total = price * guests

    return (
        f"Restaurant: {selected['name']}\n"
        f"Restaurant ID: {selected['id']}\n"
        f"Guests: {guests}\n"
        f"Price per person: Rs. {price}\n"
        f"Estimated total cost: Rs. {total}"
    )
