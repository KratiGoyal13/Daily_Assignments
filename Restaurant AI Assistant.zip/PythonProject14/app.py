
import json
import uuid
from pathlib import Path

import streamlit as st

from agent import run_agent
from tools import calculate_dining_cost




st.set_page_config(
    page_title="DineWise - Restaurant AI Assistant",
    page_icon="🍽️",
    layout="wide",
    initial_sidebar_state="expanded"
)

BASE_DIR = Path(__file__).parent
DATA_FILE = BASE_DIR / "restaurants.json"
CSS_FILE = BASE_DIR / "styles.css"


# =====================================================
# 2. LOAD CUSTOM CSS
# =====================================================

if CSS_FILE.exists():
    css = CSS_FILE.read_text(encoding="utf-8")
    st.markdown(
        f"<style>{css}</style>",
        unsafe_allow_html=True
    )

# Additional styling for restaurant pictures
st.markdown(
    """
    <style>
    [data-testid="stImage"] img {
        width: 100%;
        height: 190px;
        object-fit: cover;
        border-radius: 10px;
    }

    .restaurant-id {
        color: #89938e;
        font-size: 12px;
    }

    .restaurant-subtitle {
        color: #7a8580;
        font-size: 14px;
    }

    .main-heading {
        background: linear-gradient(120deg, #183d32, #32654e);
        padding: 28px;
        border-radius: 16px;
        color: white;
        margin-bottom: 28px;
    }

    .main-heading h1 {
        color: white;
    }

    .main-heading p {
        color: #e4eee8;
    }
    </style>
    """,
    unsafe_allow_html=True
)


# =====================================================
# 3. LOAD RESTAURANT DATA
# =====================================================

@st.cache_data
def load_restaurants():

    if not DATA_FILE.exists():
        return []

    with open(DATA_FILE, "r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, list):
        raise ValueError("restaurants.json must contain a list.")

    return data


try:
    restaurants = load_restaurants()
except (json.JSONDecodeError, OSError, ValueError) as error:
    st.error(f"Unable to load restaurant data: {error}")
    st.stop()

if not restaurants:
    st.warning("No restaurants found in restaurants.json.")
    st.stop()



if "thread_id" not in st.session_state:
    st.session_state.thread_id = str(uuid.uuid4())

if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = []

if "tool_count" not in st.session_state:
    st.session_state.tool_count = 0

if "guardrail_count" not in st.session_state:
    st.session_state.guardrail_count = 0


def format_price(value):
    return f"₹{value:,.0f}"


def get_restaurant_image(restaurant):
    """
    Select a food image based on the restaurant cuisine.
    Specific cuisine names are checked before general names.
    """

    cuisine = str(restaurant.get("cuisine", "")).lower()

    images = {
        "south indian":
            "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800",

        "north indian":
            "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=800",

        "indian":
            "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800",

        "italian":
            "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800",

        "chinese":
            "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=800",

        "mexican":
            "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=800",

        "default":
            "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800"
    }

    for cuisine_name, image_url in images.items():

        if cuisine_name == "default":
            continue

        if cuisine_name in cuisine:
            return image_url

    return images["default"]


def display_restaurant_card(restaurant):

    name = restaurant.get("name", "Unknown Restaurant")
    cuisine = restaurant.get("cuisine", "Not specified")
    location = restaurant.get("location", "Not specified")
    restaurant_id = restaurant.get("id", "N/A")

    price = restaurant.get("price_per_person", 0)
    seats = restaurant.get("available_seats", 0)

    image_url = get_restaurant_image(restaurant)

    with st.container(border=True):

        # Restaurant picture
        st.image(
            image_url,
            use_container_width=True
        )

        # Restaurant information
        st.markdown(f"### 🍽️ {name}")

        st.markdown(
            f'<p class="restaurant-subtitle">'
            f'{cuisine} · {location}'
            f'</p>',
            unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**Price per person**")
            st.markdown(f"### {format_price(price)}")

        with col2:
            st.markdown("**Available seats**")
            st.markdown(f"### {seats}")

        st.caption(f"Restaurant ID: {restaurant_id}")


def display_restaurant_grid(restaurant_list):

    for i in range(0, len(restaurant_list), 3):

        columns = st.columns(3)

        for column, restaurant in zip(
            columns,
            restaurant_list[i:i + 3]
        ):

            with column:
                display_restaurant_card(restaurant)


def reset_conversation():

    st.session_state.thread_id = str(uuid.uuid4())
    st.session_state.chat_messages = []
    st.rerun()




with st.sidebar:

    st.markdown("# 🍽️ DineWise")

    st.caption("Your intelligent dining companion")

    st.divider()

    page = st.radio(
        "NAVIGATION",
        [
            "Dashboard",
            "Explore Restaurants",
            "Cost Calculator",
            "AI Assistant",
            "Guardrails"
        ]
    )

    st.divider()

    st.markdown("### System Status")

    st.markdown(
        '<span class="status-dot"></span> Application running',
        unsafe_allow_html=True
    )

    st.caption("LangChain · Streamlit · Python")

    st.divider()

    st.markdown("### Conversation")

    if st.button(
        "＋ New Conversation",
        use_container_width=True
    ):
        reset_conversation()

    st.caption(
        "Conversation memory is maintained separately "
        "for each session."
    )


# =====================================================
# 7. COMMON HEADER
# =====================================================

st.markdown(
    """
    <div class="main-heading">
        <h1>Restaurant AI Assistant</h1>
        <p>
            Discover restaurants, explore cuisines
            and estimate dining costs.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)


# =====================================================
# PAGE 1: DASHBOARD
# =====================================================

if page == "Dashboard":

    st.markdown("## Welcome to DineWise 👋")

    st.write(
        "Your smart platform for exploring dining options."
    )

    total_restaurants = len(restaurants)

    cuisines = set(
        r.get("cuisine", "") for r in restaurants
    )

    locations = set(
        r.get("location", "") for r in restaurants
    )

    average_price = (
        sum(
            r.get("price_per_person", 0)
            for r in restaurants
        ) / total_restaurants
        if total_restaurants else 0
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Restaurants", total_restaurants)

    with col2:
        st.metric("Cuisines", len(cuisines))

    with col3:
        st.metric("Locations", len(locations))

    with col4:
        st.metric("Average Price", format_price(average_price))

    st.divider()

    st.markdown("## Discover popular dining options")

    st.write(
        "Explore restaurants from your available dataset."
    )

    featured = restaurants[:6]

    display_restaurant_grid(featured)

    st.divider()

    st.info(
        "Use Explore Restaurants to search by cuisine, "
        "restaurant name or location."
    )




elif page == "Explore Restaurants":

    st.markdown("## Explore Restaurants")

    st.write(
        "Find a restaurant that matches your preferences."
    )

    search = st.text_input(
        "Search",
        placeholder="Search restaurant, cuisine or location..."
    )

    all_cuisines = sorted(
        set(r.get("cuisine", "") for r in restaurants)
    )

    all_locations = sorted(
        set(r.get("location", "") for r in restaurants)
    )

    col1, col2 = st.columns(2)

    with col1:

        cuisine_filter = st.selectbox(
            "Filter by cuisine",
            ["All"] + all_cuisines
        )

    with col2:

        location_filter = st.selectbox(
            "Filter by location",
            ["All"] + all_locations
        )

    filtered = []

    for restaurant in restaurants:

        name = str(restaurant.get("name", "")).lower()
        cuisine = str(restaurant.get("cuisine", "")).lower()
        location = str(restaurant.get("location", "")).lower()

        matches_search = (
            not search
            or search.lower() in name
            or search.lower() in cuisine
            or search.lower() in location
        )

        matches_cuisine = (
            cuisine_filter == "All"
            or restaurant.get("cuisine") == cuisine_filter
        )

        matches_location = (
            location_filter == "All"
            or restaurant.get("location") == location_filter
        )

        if (
            matches_search
            and matches_cuisine
            and matches_location
        ):
            filtered.append(restaurant)

    st.caption(f"{len(filtered)} restaurants found")

    if filtered:

        display_restaurant_grid(filtered)

    else:

        st.warning("No matching restaurants found.")


# =====================================================
# PAGE 3: COST CALCULATOR
# =====================================================

elif page == "Cost Calculator":

    st.markdown("## Dining Cost Calculator")

    st.write(
        "Calculate your estimated dining expense "
        "before choosing a restaurant."
    )

    restaurant_options = {
        f"{r.get('name', 'Unknown')} ({r.get('id', 'N/A')})": r
        for r in restaurants
    }

    selected_name = st.selectbox(
        "Select restaurant",
        list(restaurant_options.keys())
    )

    selected = restaurant_options[selected_name]

    st.image(
        get_restaurant_image(selected),
        width=500
    )

    st.markdown(
        f"**Cuisine:** {selected.get('cuisine', 'N/A')}  \n"
        f"**Location:** {selected.get('location', 'N/A')}  \n"
        f"**Price per person:** "
        f"{format_price(selected.get('price_per_person', 0))}  \n"
        f"**Available seats:** "
        f"{selected.get('available_seats', 0)}"
    )

    guests = st.number_input(
        "Number of guests",
        min_value=1,
        max_value=20,
        value=2,
        step=1
    )

    if st.button(
        "Calculate Estimated Cost",
        type="primary",
        use_container_width=True
    ):

        result = calculate_dining_cost.invoke({
            "restaurant_id": selected["id"],
            "guests": int(guests)
        })

        total = selected["price_per_person"] * int(guests)

        st.divider()

        st.success("Estimated dining cost calculated!")

        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric(
                "Price per person",
                format_price(selected["price_per_person"])
            )

        with col2:
            st.metric("Guests", int(guests))

        with col3:
            st.metric(
                "Estimated total",
                format_price(total)
            )

        with st.expander("View calculation details"):
            st.code(result)

        st.caption(
            "This is an estimate only. Actual dining costs may vary."
        )


# =====================================================
# PAGE 4: AI ASSISTANT
# =====================================================

elif page == "AI Assistant":

    st.markdown("## 🤖 AI Restaurant Assistant")

    st.write(
        "Ask me to discover restaurants, compare cuisines "
        "or calculate dining costs."
    )

    col1, col2 = st.columns([3, 1])

    with col1:
        st.caption("Powered by LangChain and GPT-4o-mini")

    with col2:

        if st.button("Clear Chat"):
            reset_conversation()

    st.markdown("### Try asking")

    suggestions = [
        "Show me Indian restaurants.",
        "Find Italian restaurants.",
        "Calculate Spice Garden cost for 4 guests."
    ]

    suggestion_cols = st.columns(3)

    for column, suggestion in zip(
        suggestion_cols,
        suggestions
    ):

        with column:

            if st.button(
                suggestion,
                use_container_width=True
            ):

                st.session_state.pending_prompt = suggestion
                st.rerun()

    # Display chat history
    for chat in st.session_state.chat_messages:

        with st.chat_message(chat["role"]):

            st.markdown(chat["content"])

            if chat.get("tool_calls"):

                with st.expander("View tool execution"):

                    for call in chat["tool_calls"]:

                        st.write("Tool:", call["name"])
                        st.json(call["arguments"])

    prompt = st.chat_input(
        "Ask something about restaurants..."
    )

    # Handle suggested prompts
    if "pending_prompt" in st.session_state:

        prompt = st.session_state.pop("pending_prompt")

    if prompt:

        st.session_state.chat_messages.append({
            "role": "user",
            "content": prompt
        })

        with st.chat_message("user"):
            st.markdown(prompt)

        with st.chat_message("assistant"):

            with st.spinner("Thinking..."):

                try:

                    result = run_agent(
                        prompt,
                        st.session_state.thread_id
                    )

                    response = result["response"]
                    tool_calls = result.get("tool_calls", [])

                    st.markdown(response)

                    if tool_calls:

                        st.session_state.tool_count += len(tool_calls)

                        with st.expander("Tool execution details"):

                            for call in tool_calls:

                                st.write(
                                    "**Tool:**",
                                    call["name"]
                                )

                                st.json(call["arguments"])

                    if not result["ok"]:

                        st.session_state.guardrail_count += 1

                        st.warning(
                            f"Request handled by: "
                            f"{result.get('guardrail', 'Guardrail')}"
                        )

                except Exception as error:

                    response = (
                        "I could not process your request. "
                        "Please check the backend configuration "
                        f"and try again. Details: {error}"
                    )

                    tool_calls = []

                    st.error(response)

        st.session_state.chat_messages.append({
            "role": "assistant",
            "content": response,
            "tool_calls": tool_calls
        })




elif page == "Guardrails":

    st.markdown("## 🛡️ Guardrail Monitoring")

    st.write(
        "Monitor the safety checks used by the AI assistant."
    )

    col1, col2 = st.columns(2)

    with col1:

        st.metric(
            "Blocked requests this session",
            st.session_state.guardrail_count
        )

    with col2:

        st.metric(
            "Tool executions this session",
            st.session_state.tool_count
        )

    st.divider()

    st.markdown("### Active protection mechanisms")

    protections = [
        (
            "Input validation",
            "Rejects empty or long questions."
        ),
        (
            "Domain restriction",
            "Allows restaurant-related requests only."
        ),
        (
            "Guest validation",
            "Allows 1 to 20 guests."
        ),
        (
            "PII detection",
            "Detects emails and phone numbers."
        ),
        (
            "Output redaction",
            "Masks personal information in responses."
        ),
        (
            "Conversation handling",
            "Supports contextual follow-ups."
        )
    ]

    for name, description in protections:

        with st.container(border=True):

            col1, col2 = st.columns([1, 4])

            with col1:
                st.success("ACTIVE")

            with col2:
                st.markdown(f"**{name}**")
                st.caption(description)

    st.divider()

    st.info(
        "Guardrails are applied in the Python backend "
        "before and after AI processing."
    )


st.divider()

st.caption(
    "DineWise | Restaurant AI Assistant | "
    "Powered by Python, Streamlit and LangChain"
)
