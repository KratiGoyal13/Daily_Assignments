
from guardrails import (
    validate_input,
    detect_pii,
    redact_pii,
    is_restaurant_related
)

print("========== GUARDRAIL TESTING ==========")

# Test 1: Empty input
print("\nTest 1: Empty input")
print(validate_input(""))

# Test 2: Long input
print("\nTest 2: Long input")
print(validate_input("A" * 501))

# Test 3: Restaurant question
print("\nTest 3: Restaurant question")
print(is_restaurant_related("Show me Indian restaurants."))

# Test 4: Unrelated question
print("\nTest 4: Unrelated question")
print(is_restaurant_related("What is the largest mammal?"))

# Test 5: Contextual follow-up
print("\nTest 5: Follow-up")
print(is_restaurant_related("Make that 6 people.", True))

# Test 6: PII detection
print("\nTest 6: PII detection")
message = "My email is john@example.com."
print(detect_pii(message))

# Test 7: PII redaction
print("\nTest 7: PII redaction")
print(redact_pii(message))

print("\n========== TESTING COMPLETED ==========")
