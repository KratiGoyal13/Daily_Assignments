
from tools import search_restaurants, calculate_dining_cost

print("========== TOOL 1: SEARCH RESTAURANTS ==========")

result = search_restaurants.invoke({
    "keyword": "Indian"
})

print(result)


print("\n========== TOOL 2: CALCULATE DINING COST ==========")

result = calculate_dining_cost.invoke({
    "restaurant_id": "R101",
    "guests": 4
})

print(result)


print("\n========== INVALID GUEST COUNT ==========")

result = calculate_dining_cost.invoke({
    "restaurant_id": "R101",
    "guests": 50
})

print(result)
