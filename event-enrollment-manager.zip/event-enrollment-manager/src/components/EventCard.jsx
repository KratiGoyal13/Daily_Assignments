
function EventCard({ event, availableSeats, onRegister }) {
  return (
    <div className="event-card">

      <div className="event-image">
        <img src={event.image} alt={event.title} />

        <span className="category">
          {event.category}
        </span>
      </div>

      <div className="event-details">

        <h3>{event.title}</h3>

        <p>📅 {event.date}</p>
        <p>🕒 {event.time}</p>

        <div className="seat-info">
          <span>Total Seats</span>
          <strong>{event.capacity}</strong>
        </div>

        <div className="seat-info">
          <span>Available Seats</span>
          <strong>{availableSeats}</strong>
        </div>

        <button
          className="register-btn"
          onClick={() => onRegister(event)}
          disabled={availableSeats === 0}
        >
          {availableSeats === 0
            ? "Fully Booked"
            : "Register Now →"}
        </button>

      </div>
    </div>
  );
}

export default EventCard;
