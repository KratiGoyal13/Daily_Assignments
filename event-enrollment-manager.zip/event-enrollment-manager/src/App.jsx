
import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Events from "./pages/Events";
import Registrations from "./pages/Registrations";

import "./App.css";

function App() {
  const [registrations, setRegistrations] = useState(() => {
    try {
      return JSON.parse(
        localStorage.getItem("registrations") || "[]"
      );
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(
      "registrations",
      JSON.stringify(registrations)
    );
  }, [registrations]);

  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route
          path="/"
          element={
            <Events
              registrations={registrations}
              setRegistrations={setRegistrations}
            />
          }
        />

        <Route
          path="/registrations"
          element={
            <Registrations
              registrations={registrations}
              setRegistrations={setRegistrations}
            />
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
