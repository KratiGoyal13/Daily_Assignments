
const events = [
  {
    id: "EV101",
    title: "Intro to Cloud Computing",
    category: "Technology",
    date: "2026-11-10",
    time: "10:00",
    capacity: 4,
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=900"
  },
  {
    id: "EV102",
    title: "Creative Writing Lab",
    category: "Arts",
    date: "2026-11-12",
    time: "14:00",
    capacity: 3,
    image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=900"
  },
  {
    id: "EV103",
    title: "Data Visualization Basics",
    category: "Technology",
    date: "2026-11-14",
    time: "11:00",
    capacity: 5,
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=900"
  },
  {
    id: "EV104",
    title: "Personal Finance Essentials",
    category: "Life Skills",
    date: "2026-11-16",
    time: "16:00",
    capacity: 4,
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=900"
  },
  {
    id: "EV105",
    title: "Public Speaking Practice",
    category: "Life Skills",
    date: "2026-11-18",
    time: "10:30",
    capacity: 3,
    image: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=900"
  },
  {
    id: "EV106",
    title: "Digital Illustration Studio",
    category: "Arts",
    date: "2026-11-20",
    time: "13:00",
    capacity: 2,
    image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=900"
  }
];

export default events;
