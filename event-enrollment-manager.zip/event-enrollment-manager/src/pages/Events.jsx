
import { useState } from "react";
import eventsData from "../data/events";
import EventCard from "../components/EventCard";
import RegistrationForm from "../components/RegistrationForm";

function Events({ registrations, setRegistrations }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [message, setMessage] = useState("");

  const filteredEvents = eventsData.filter((event) => {
    return (
      event.title.toLowerCase().includes(search.toLowerCase()) &&
      (category === "All" || event.category === category)
    );
  });

  const getAvailableSeats = (event) => {
    const booked = registrations.filter(
      (r) => r.eventId === event.id
    ).length;

    return event.capacity - booked;
  };

  const handleRegister = (details) => {
    const normalizedEmail = details.email.trim().toLowerCase();

    const alreadyRegistered = registrations.some(
      (r) =>
        r.eventId === selectedEvent.id &&
        r.email.toLowerCase() === normalizedEmail
    );

    if (alreadyRegistered) {
      setMessage("This email is already registered for this event.");
      return;
    }

    if (getAvailableSeats(selectedEvent) <= 0) {
      setMessage("Sorry, this event is fully booked.");
      return;
    }

    const newRegistration = {
      id: Date.now(),
      eventId: selectedEvent.id,
      eventTitle: selectedEvent.title,
      eventDate: selectedEvent.date,
      name: details.name,
      email: normalizedEmail
    };

    setRegistrations((prev) => [...prev, newRegistration]);

    setMessage("Registration successful!");
    setSelectedEvent(null);
  };

  return (
    <div className="container">
      <h1>Upcoming Events</h1>

      {message && <p className="success">{message}</p>}

      <div className="filters">
        <input
          type="text"
          placeholder="Search events..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option>All</option>
          <option>Technology</option>
          <option>Arts</option>
          <option>Life Skills</option>
        </select>
      </div>

      <div className="event-grid">
        {filteredEvents.length > 0 ? (
          filteredEvents.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              availableSeats={getAvailableSeats(event)}
              onRegister={(event) => {
                setMessage("");
                setSelectedEvent(event);
              }}
            />
          ))
        ) : (
          <p>No events found. Try another search or category.</p>
        )}
      </div>

      {selectedEvent && (
        <RegistrationForm
          event={selectedEvent}
          onSubmit={handleRegister}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  );
}

export default Events;
