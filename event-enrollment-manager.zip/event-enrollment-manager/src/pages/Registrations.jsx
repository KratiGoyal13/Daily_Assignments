
import eventsData from "../data/events";

function Registrations({ registrations, setRegistrations }) {

  const cancelRegistration = (id) => {
    const confirmCancel = window.confirm(
      "Are you sure you want to cancel this registration?"
    );

    if (confirmCancel) {
      setRegistrations((prev) =>
        prev.filter((registration) => registration.id !== id)
      );
    }
  };

  return (
    <div className="container">
      <h1>My Registrations</h1>

      {registrations.length === 0 ? (
        <p>No registrations available.</p>
      ) : (
        registrations.map((registration) => {
          const event = eventsData.find(
            (e) => e.id === registration.eventId
          );

          return (
            <div className="registration-card" key={registration.id}>
              <h3>{registration.eventTitle}</h3>

              <p>Name: {registration.name}</p>
              <p>Email: {registration.email}</p>
              <p>Event Date: {event?.date || registration.eventDate}</p>

              <button
                className="cancel-btn"
                onClick={() => cancelRegistration(registration.id)}
              >
                Cancel Registration
              </button>
            </div>
          );
        })
      )}
    </div>
  );
}

export default Registrations;
