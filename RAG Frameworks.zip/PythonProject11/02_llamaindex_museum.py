
from pathlib import Path
import chromadb

from llama_index.core import (
    SimpleDirectoryReader,
    VectorStoreIndex,
    StorageContext,
    Settings
)

from llama_index.core.node_parser import SentenceSplitter

from llama_index.embeddings.huggingface import HuggingFaceEmbedding

from llama_index.vector_stores.chroma import ChromaVectorStore


# ==========================================
# 1. PROJECT PATHS
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent

DOCUMENTS_DIR = PROJECT_DIR / "Documents"
CHROMA_DIR = PROJECT_DIR / "chroma_db"

COLLECTION_NAME = "museum_llamaindex"


# ==========================================
# 2. LOAD DOCUMENTS
# ==========================================

def load_documents():

    print("\n========== LOADING DOCUMENTS ==========")

    if not DOCUMENTS_DIR.exists():
        raise FileNotFoundError(
            f"Documents folder not found: {DOCUMENTS_DIR}"
        )

    reader = SimpleDirectoryReader(
        input_dir=str(DOCUMENTS_DIR),
        required_exts=[".txt"]
    )

    documents = reader.load_data()

    print(f"Total documents loaded: {len(documents)}")

    for document in documents:
        source = document.metadata.get(
            "file_name", "Unknown"
        )
        print(f"Loaded: {source}")

    return documents


# ==========================================
# 3. CREATE NODES USING SENTENCE SPLITTER
# ==========================================

def create_nodes(documents):

    print("\n========== CREATING NODES ==========")

    splitter = SentenceSplitter(
        chunk_size=150,
        chunk_overlap=20
    )

    nodes = splitter.get_nodes_from_documents(
        documents
    )

    print(f"Total nodes created: {len(nodes)}")

    for i, node in enumerate(nodes, start=1):

        print(f"\nNode {i}")

        print(
            "Source:",
            node.metadata.get("file_name", "Unknown")
        )

        print("Content:", node.text[:150], "...")

    return nodes


# ==========================================
# 4. LOAD LOCAL MINILM EMBEDDING MODEL
# ==========================================

def create_embedding_model():

    print("\n========== LOADING EMBEDDING MODEL ==========")

    embedding_model = HuggingFaceEmbedding(
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        device="cpu"
    )

    Settings.embed_model = embedding_model

    print("Local MiniLM embedding model loaded successfully!")

    return embedding_model


# ==========================================
# 5. CREATE CHROMADB VECTOR STORE
# ==========================================

def create_vector_store():

    print("\n========== CREATING CHROMADB ==========")

    CHROMA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR)
    )

    # Delete old collection before rebuilding
    # to avoid duplicate nodes on rerunning.

    try:
        client.delete_collection(
            name=COLLECTION_NAME
        )
    except Exception:
        pass

    collection = client.get_or_create_collection(
        name=COLLECTION_NAME
    )

    vector_store = ChromaVectorStore(
        chroma_collection=collection
    )

    print(f"Collection created: {COLLECTION_NAME}")

    return vector_store


# ==========================================
# 6. BUILD VECTOR STORE INDEX
# ==========================================

def build_index(nodes, vector_store):

    print("\n========== BUILDING VECTOR STORE INDEX ==========")

    storage_context = StorageContext.from_defaults(
        vector_store=vector_store
    )

    index = VectorStoreIndex(
        nodes,
        storage_context=storage_context
    )

    print("VectorStoreIndex created successfully!")

    return index


# ==========================================
# 7. RETRIEVE TOP 2 MATCHING NODES
# ==========================================

def search_documents(retriever, question):

    print("\n==========================================")
    print("QUESTION:", question)
    print("==========================================")

    results = retriever.retrieve(question)

    if not results:
        print("No matching nodes found.")
        return

    for i, result in enumerate(results, start=1):

        node = result.node

        source = node.metadata.get(
            "file_name",
            node.metadata.get("file_path", "Unknown")
        )

        print(f"\nRESULT {i}")

        print("Source:", Path(source).name)

        print(
            "Similarity Score:",
            round(float(result.score or 0), 4)
        )

        print("Retrieved Content:")
        print(node.get_content())

        print("-" * 60)


# ==========================================
# 8. MAIN PROGRAM
# ==========================================

def main():

    print("\n")
    print("=" * 60)
    print(" LLAMAINDEX - HARBORLIGHT SCIENCE MUSEUM RAG ")
    print("=" * 60)

    # Load documents
    documents = load_documents()

    # Create nodes
    nodes = create_nodes(documents)

    # Load embeddings
    create_embedding_model()

    # Create ChromaDB vector store
    vector_store = create_vector_store()

    # Build index
    index = build_index(
        nodes,
        vector_store
    )

    # Create retriever
    retriever = index.as_retriever(
        similarity_top_k=2
    )

    print("\n========== SEARCH MENU ==========")

    questions = [
        "When does the museum close on Thursdays?",
        "What is the adult admission ticket price?",
        "What age group can join Robotics Starter Lab?",
        "When does Space Explorers take place?",
        "What happens if the museum cancels a workshop?",
        "Is free parking available at the museum?"
    ]

    # Run all six assignment questions
    for question in questions:

        search_documents(
            retriever,
            question
        )

    # Custom question option
    print("\n========== CUSTOM SEARCH ==========")

    while True:

        question = input(
            "\nEnter your question (or type exit): "
        ).strip()

        if question.lower() == "exit":
            print("Program completed.")
            break

        if question:
            search_documents(
                retriever,
                question
            )


if __name__ == "__main__":
    main()
