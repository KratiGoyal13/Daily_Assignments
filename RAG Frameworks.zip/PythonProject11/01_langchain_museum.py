
from pathlib import Path
import chromadb

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


# ==========================================
# 1. PROJECT PATHS
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent
DOCUMENTS_DIR = PROJECT_DIR / "Documents"
CHROMA_DIR = PROJECT_DIR / "chroma_db"

COLLECTION_NAME = "museum_langchain"

FILES = [
    DOCUMENTS_DIR / "Visitor_Guide.txt",
    DOCUMENTS_DIR / "Workshops_and_Events.txt"
]


# ==========================================
# 2. LOAD DOCUMENTS
# ==========================================

def load_documents():

    documents = []

    print("\n========== LOADING DOCUMENTS ==========")

    for file_path in FILES:

        if not file_path.exists():
            raise FileNotFoundError(
                f"File not found: {file_path}"
            )

        text = file_path.read_text(encoding="utf-8")

        document = Document(
            page_content=text,
            metadata={
                "source": file_path.name
            }
        )

        documents.append(document)

        print(f"Loaded: {file_path.name}")

    return documents


# ==========================================
# 3. SPLIT DOCUMENTS INTO CHUNKS
# ==========================================

def split_documents(documents):

    print("\n========== SPLITTING DOCUMENTS ==========")

    splitter = RecursiveCharacterTextSplitter.from_huggingface_tokenizer(
        tokenizer=__import__(
            "transformers"
        ).AutoTokenizer.from_pretrained(
            "sentence-transformers/all-MiniLM-L6-v2"
        ),
        chunk_size=150,
        chunk_overlap=20
    )

    chunks = splitter.split_documents(documents)

    print(f"Total chunks created: {len(chunks)}")

    for i, chunk in enumerate(chunks, start=1):
        print(f"\nChunk {i}")
        print(f"Source: {chunk.metadata['source']}")
        print(f"Content: {chunk.page_content[:150]}...")

    return chunks


# ==========================================
# 4. CREATE LOCAL EMBEDDINGS
# ==========================================

def create_embeddings():

    print("\n========== LOADING EMBEDDING MODEL ==========")

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        model_kwargs={
            "device": "cpu"
        },
        encode_kwargs={
            "normalize_embeddings": True
        }
    )

    print("Local embedding model loaded successfully!")

    return embeddings


# ==========================================
# 5. STORE CHUNKS IN CHROMADB
# ==========================================

def create_vector_database(chunks, embeddings):

    print("\n========== CREATING CHROMADB ==========")

    CHROMA_DIR.mkdir(parents=True, exist_ok=True)

    # Remove the old collection so rerunning the
    # program does not create duplicate chunks.

    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR)
    )

    try:
        client.delete_collection(
            name=COLLECTION_NAME
        )
    except Exception:
        pass

    vector_store = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=str(CHROMA_DIR)
    )

    print(f"Collection created: {COLLECTION_NAME}")
    print(f"Chunks stored: {len(chunks)}")

    return vector_store


# ==========================================
# 6. RETRIEVE TOP 2 MATCHING CHUNKS
# ==========================================

def search_documents(vector_store, question):

    print("\n==========================================")
    print("QUESTION:", question)
    print("==========================================")

    results = vector_store.similarity_search_with_score(
        query=question,
        k=2
    )

    for i, (document, distance) in enumerate(
        results, start=1
    ):

        print(f"\nRESULT {i}")

        print(
            "Source:",
            document.metadata.get("source", "Unknown")
        )

        print(
            "Distance:",
            round(float(distance), 4)
        )

        print("Retrieved Content:")
        print(document.page_content)

        print("-" * 60)


# ==========================================
# 7. MAIN PROGRAM
# ==========================================

def main():

    print("\n")
    print("=" * 60)
    print(" LANGCHAIN - HARBORLIGHT SCIENCE MUSEUM RAG ")
    print("=" * 60)

    # Load documents
    documents = load_documents()

    # Split documents
    chunks = split_documents(documents)

    # Load local embedding model
    embeddings = create_embeddings()

    # Create vector database
    vector_store = create_vector_database(
        chunks,
        embeddings
    )

    # Assignment questions
    questions = [
        "When does the museum close on Thursdays?",
        "What is the adult admission ticket price?",
        "What age group can join Robotics Starter Lab?",
        "When does Space Explorers take place?",
        "What happens if the museum cancels a workshop?",
        "Is free parking available at the museum?"
    ]

    print("\n========== SEARCH MENU ==========")

    for question in questions:

        search_documents(
            vector_store,
            question
        )

    # Allow additional questions
    print("\n========== CUSTOM SEARCH ==========")

    while True:

        question = input(
            "\nEnter your question (or type exit): "
        ).strip()

        if question.lower() == "exit":
            print("Program completed.")
            break

        if question:
            search_documents(
                vector_store,
                question
            )


if __name__ == "__main__":
    main()
