
from pathlib import Path
from haystack.utils import ComponentDevice
from haystack import Document, Pipeline
from haystack.document_stores.in_memory import InMemoryDocumentStore

from haystack.components.preprocessors import DocumentSplitter

from haystack_integrations.components.embedders.sentence_transformers import (
    SentenceTransformersDocumentEmbedder,
    SentenceTransformersTextEmbedder
)

from haystack.components.writers import DocumentWriter
from haystack.document_stores.types import DuplicatePolicy

from haystack.components.retrievers.in_memory import (
    InMemoryEmbeddingRetriever
)


# ==========================================
# 1. PROJECT PATHS
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent

DOCUMENTS_DIR = PROJECT_DIR / "Documents"

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"


# ==========================================
# 2. LOAD DOCUMENTS
# ==========================================

def load_documents():

    print("\n========== LOADING DOCUMENTS ==========")

    documents = []

    files = [
        DOCUMENTS_DIR / "Visitor_Guide.txt",
        DOCUMENTS_DIR / "Workshops_and_Events.txt"
    ]

    for file_path in files:

        if not file_path.exists():
            raise FileNotFoundError(
                f"File not found: {file_path}"
            )

        content = file_path.read_text(
            encoding="utf-8"
        )

        document = Document(
            content=content,
            meta={
                "source": file_path.name
            }
        )

        documents.append(document)

        print(f"Loaded: {file_path.name}")

    print(f"Total documents loaded: {len(documents)}")

    return documents


# ==========================================
# 3. CREATE IN-MEMORY DOCUMENT STORE
# ==========================================

def create_document_store():

    print("\n========== CREATING DOCUMENT STORE ==========")

    document_store = InMemoryDocumentStore(
        embedding_similarity_function="cosine"
    )

    print("InMemoryDocumentStore created successfully!")

    return document_store


# ==========================================
# 4. BUILD INDEXING PIPELINE
# ==========================================

def create_indexing_pipeline(document_store):

    print("\n========== BUILDING INDEXING PIPELINE ==========")

    # Split documents into 100-word chunks
    # with 15-word overlap.

    splitter = DocumentSplitter(
        split_by="word",
        split_length=100,
        split_overlap=15
    )

    # Generate embeddings for document chunks

    document_embedder = SentenceTransformersDocumentEmbedder(
        model=MODEL_NAME,
        device=ComponentDevice.from_str("cpu")
    )

    # Store documents and their embeddings

    writer = DocumentWriter(
        document_store=document_store,
        policy=DuplicatePolicy.OVERWRITE
    )

    # Load the local embedding model

    document_embedder.warm_up()

    # Create pipeline

    indexing_pipeline = Pipeline()

    indexing_pipeline.add_component(
        "splitter",
        splitter
    )

    indexing_pipeline.add_component(
        "document_embedder",
        document_embedder
    )

    indexing_pipeline.add_component(
        "writer",
        writer
    )

    # Connect components

    indexing_pipeline.connect(
        "splitter.documents",
        "document_embedder.documents"
    )

    indexing_pipeline.connect(
        "document_embedder.documents",
        "writer.documents"
    )

    print("Indexing pipeline created successfully!")

    return indexing_pipeline


# ==========================================
# 5. RUN INDEXING PIPELINE
# ==========================================

def index_documents(indexing_pipeline, documents):

    print("\n========== RUNNING INDEXING PIPELINE ==========")

    result = indexing_pipeline.run(
        {
            "splitter": {
                "documents": documents
            }
        },
        include_outputs_from={"splitter"}
    )

    chunks = result["splitter"]["documents"]

    print(f"Total chunks created: {len(chunks)}")

    for i, chunk in enumerate(chunks, start=1):

        print(f"\nChunk {i}")

        print(
            "Source:",
            chunk.meta.get("source", "Unknown")
        )

        print("Content:", chunk.content[:150], "...")

    print(
        "\nDocuments written:",
        result["writer"]["documents_written"]
    )

    return len(chunks)


# ==========================================
# 6. BUILD QUERY PIPELINE
# ==========================================

def create_query_pipeline(document_store):

    print("\n========== BUILDING QUERY PIPELINE ==========")

    # Convert user question into an embedding

    text_embedder = SentenceTransformersTextEmbedder(
        model=MODEL_NAME,
        device=ComponentDevice.from_str("cpu")
    )

    text_embedder.warm_up()

    # Retrieve top 2 matching chunks

    retriever = InMemoryEmbeddingRetriever(
        document_store=document_store,
        top_k=2
    )

    # Create query pipeline

    query_pipeline = Pipeline()

    query_pipeline.add_component(
        "text_embedder",
        text_embedder
    )

    query_pipeline.add_component(
        "retriever",
        retriever
    )

    # Connect question embedding to retriever

    query_pipeline.connect(
        "text_embedder.embedding",
        "retriever.query_embedding"
    )

    print("Query pipeline created successfully!")

    return query_pipeline


# ==========================================
# 7. RETRIEVE TOP 2 MATCHING CHUNKS
# ==========================================

def search_documents(query_pipeline, question):

    print("\n==========================================")
    print("QUESTION:", question)
    print("==========================================")

    result = query_pipeline.run(
        {
            "text_embedder": {
                "text": question
            }
        }
    )

    documents = result["retriever"]["documents"]

    if not documents:
        print("No matching documents found.")
        return

    for i, document in enumerate(documents, start=1):

        print(f"\nRESULT {i}")

        print(
            "Source:",
            document.meta.get("source", "Unknown")
        )

        print(
            "Similarity Score:",
            round(float(document.score or 0), 4)
        )

        print("Retrieved Content:")
        print(document.content)

        print("-" * 60)


# ==========================================
# 8. MAIN PROGRAM
# ==========================================

def main():

    print("\n")
    print("=" * 60)
    print(" HAYSTACK - HARBORLIGHT SCIENCE MUSEUM RAG ")
    print("=" * 60)

    # Load museum documents

    documents = load_documents()

    # Create in-memory document store

    document_store = create_document_store()

    # Build indexing pipeline

    indexing_pipeline = create_indexing_pipeline(
        document_store
    )

    # Index documents

    index_documents(
        indexing_pipeline,
        documents
    )

    # Build query pipeline

    query_pipeline = create_query_pipeline(
        document_store
    )

    # Assignment questions

    questions = [
        "When does the museum close on Thursdays?",
        "What is the adult admission ticket price?",
        "What age group can join Robotics Starter Lab?",
        "When does Space Explorers take place?",
        "What happens if the museum cancels a workshop?",
        "Is free parking available at the museum?"
    ]

    print("\n========== SEARCH MENU ==========")

    for question in questions:

        search_documents(
            query_pipeline,
            question
        )

    # Custom question option

    print("\n========== CUSTOM SEARCH ==========")

    while True:

        question = input(
            "\nEnter your question (or type exit): "
        ).strip()

        if question.lower() == "exit":
            print("Program completed.")
            break

        if question:
            search_documents(
                query_pipeline,
                question
            )


if __name__ == "__main__":
    main()
