
import psycopg2

# Connect to PostgreSQL
conn = psycopg2.connect(
    host="localhost",
    database="library_store",
    user="postgres",
    password="Admin@123"
)

print("Connected to PostgreSQL successfully")

cursor = conn.cursor()

# Insert books
books = [
    (201, "Atomic Habits", "James Clear", "Self Help", 650, 12),
    (202, "Clean Code", "Robert Martin", "Technology", 900, 8),
    (203, "The Alchemist", "Paulo Coelho", "Fiction", 500, 15),
    (204, "Deep Work", "Cal Newport", "Productivity", 700, 10)
]

for book in books:
    cursor.execute(
        """
        INSERT INTO books (book_id, title, author, category, price, stock)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (book_id) DO NOTHING;
        """,
        book
    )

conn.commit()

# 4. Display all books
print("\nAll Books:")
cursor.execute("SELECT * FROM books")
for row in cursor.fetchall():
    print(row)

# 5. Technology books
print("\nTechnology Books:")
cursor.execute("SELECT * FROM books WHERE category = 'Technology'")
for row in cursor.fetchall():
    print(row)

# 6. Books with price > 600
print("\nBooks with Price > 600:")
cursor.execute("SELECT * FROM books WHERE price > 600")
for row in cursor.fetchall():
    print(row)

# 7. Update price of book 202
cursor.execute(
    "UPDATE books SET price = 950 WHERE book_id = 202"
)

# 8. Update stock of book 204
cursor.execute(
    "UPDATE books SET stock = 14 WHERE book_id = 204"
)

conn.commit()

# 9. Display updated records
print("\nUpdated Records:")
cursor.execute("SELECT * FROM books")
for row in cursor.fetchall():
    print(row)

# 10. Delete book 203
cursor.execute(
    "DELETE FROM books WHERE book_id = 203"
)

conn.commit()

# 11. Display remaining books
print("\nRemaining Books:")
cursor.execute("SELECT * FROM books")
for row in cursor.fetchall():
    print(row)

# 12. Add a new book
cursor.execute(
    """
    INSERT INTO books
    (book_id, title, author, category, price, stock)
    VALUES (%s, %s, %s, %s, %s, %s)
    ON CONFLICT (book_id) DO NOTHING
    """,
    (205, "Python Crash Course", "Eric Matthes", "Technology", 850, 20)
)

conn.commit()

print("\nAfter Adding New Book:")
cursor.execute("SELECT * FROM books")
for row in cursor.fetchall():
    print(row)

# 13. Highest priced book
print("\nHighest Priced Book:")
cursor.execute(
    "SELECT * FROM books ORDER BY price DESC LIMIT 1"
)
print(cursor.fetchone())

# 14. Total stock
print("\nTotal Stock Available:")
cursor.execute(
    "SELECT SUM(stock) FROM books"
)
print(cursor.fetchone()[0])

# 15. Count books in each category
print("\nBooks Count by Category:")
cursor.execute(
    """
    SELECT category, COUNT(*)
    FROM books
    GROUP BY category
    """
)

for row in cursor.fetchall():
    print(row)

# Close connection
cursor.close()
conn.close()
print("\nDatabase connection closed.")