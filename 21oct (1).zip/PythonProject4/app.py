from flask import Flask, jsonify, request
import psycopg2

app = Flask(__name__)

conn = psycopg2.connect(
    host="localhost",
    database="studentsdb",
    user="postgres",
    password="Admin@123"
)

@app.route("/")
def home():
    return {"message": "Student CRUD API is running"}
@app.route('/students', methods=['GET'])
def get_students():
    cur = conn.cursor()
    cur.execute("SELECT * FROM students")
    rows = cur.fetchall()

    students = []
    for row in rows:
        students.append({
            "id": row[0],
            "name": row[1],
            "course": row[2],
            "score": row[3]
        })

    cur.close()
    return jsonify(students)


# GET student by id
@app.route('/students/<int:id>', methods=['GET'])
def get_student(id):
    cur = conn.cursor()
    cur.execute("SELECT * FROM students WHERE id=%s", (id,))
    student = cur.fetchone()
    cur.close()

    if student:
        return jsonify({
            "id": student[0],
            "name": student[1],
            "course": student[2],
            "score": student[3]
        })

    return jsonify({"message": "Student not found"}), 404


# POST student
@app.route('/students', methods=['POST'])
def add_student():
    data = request.get_json()

    cur = conn.cursor()
    cur.execute(
        "INSERT INTO students (id,name,course,score) VALUES (%s,%s,%s,%s)",
        (data["id"], data["name"], data["course"], data["score"])
    )
    conn.commit()
    cur.close()

    return jsonify({"message": "Student added successfully"}), 201


# PUT student
@app.route('/students/<int:id>', methods=['PUT'])
def update_student(id):
    data = request.get_json()

    cur = conn.cursor()
    cur.execute(
        """
        UPDATE students
        SET name=%s, course=%s, score=%s
        WHERE id=%s
        """,
        (data["name"], data["course"], data["score"], id)
    )

    if cur.rowcount == 0:
        cur.close()
        return jsonify({"message": "Student not found"}), 404

    conn.commit()
    cur.close()

    return jsonify({"message": "Student updated successfully"})


# DELETE student
@app.route('/students/<int:id>', methods=['DELETE'])
def delete_student(id):
    cur = conn.cursor()

    cur.execute("DELETE FROM students WHERE id=%s", (id,))

    if cur.rowcount == 0:
        cur.close()
        return jsonify({"message": "Student not found"}), 404

    conn.commit()
    cur.close()

    return jsonify({"message": "Student deleted successfully"})


if __name__ == '__main__':
    app.run(debug=True)