
import json
from pathlib import Path
from datetime import datetime

# Get the current project folder
BASE_DIR = Path(__file__).resolve().parent

BOOKS_FILE = BASE_DIR / "books.json"
RESERVATIONS_FILE = BASE_DIR / "reservations.json"


# Read JSON data
def read_json(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        return json.load(file)


# Write JSON data
def write_json(file_path, data):
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4, ensure_ascii=False)


# TOOL 1: Search Books
def search_books(keyword):

    books = read_json(BOOKS_FILE)

    keyword = keyword.lower()

    matching_books = []

    for book in books:
        if (
            keyword in book["title"].lower()
            or keyword in book["author"].lower()
            or keyword in book["category"].lower()
        ):
            matching_books.append(book)

    if not matching_books:
        return {
            "status": "not_found",
            "message": "No matching books found."
        }

    return {
        "status": "success",
        "books": matching_books
    }


# TOOL 2: Reserve Book
def reserve_book(book_id, customer_name):

    books = read_json(BOOKS_FILE)

    # Find the requested book
    selected_book = None

    for book in books:
        if book["id"] == book_id:
            selected_book = book
            break

    # Check whether the book exists
    if selected_book is None:
        return {
            "status": "not_found",
            "message": "Book ID not found."
        }

    # Check availability
    if selected_book["available_copies"] <= 0:
        return {
            "status": "unavailable",
            "message": f"{selected_book['title']} has no available copies."
        }

    # Ask for confirmation
    print("\n========== RESERVATION CONFIRMATION ==========")
    print("Book:", selected_book["title"])
    print("Customer:", customer_name)
    print("Available copies:", selected_book["available_copies"])

    confirmation = input(
        "\nDo you want to confirm this reservation? (yes/no): "
    ).strip().lower()

    if confirmation not in ["yes", "y"]:
        return {
            "status": "cancelled",
            "message": "Reservation cancelled. No changes were made."
        }

    # Create reservation
    reservations = read_json(RESERVATIONS_FILE)

    reservation = {
        "reservation_id": len(reservations) + 1,
        "book_id": book_id,
        "book_title": selected_book["title"],
        "customer_name": customer_name,
        "reservation_date": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    }

    reservations.append(reservation)

    # Reduce available copies
    selected_book["available_copies"] -= 1

    # Save updated JSON files
    write_json(BOOKS_FILE, books)
    write_json(RESERVATIONS_FILE, reservations)

    return {
        "status": "success",
        "reservation": reservation,
        "remaining_copies": selected_book["available_copies"]
    }
