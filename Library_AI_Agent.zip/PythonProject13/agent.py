
import json
import os

from openai import OpenAI
from dotenv import load_dotenv

from tools import search_books, reserve_book


# ==========================================
# STEP 1: LOAD API KEY
# ==========================================

load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

if not api_key:
    raise ValueError("OPENAI_API_KEY is missing from .env file")

client = OpenAI(api_key=api_key)


# ==========================================
# STEP 2: DEFINE AI TOOLS
# ==========================================

tools = [

    {
        "type": "function",
        "function": {
            "name": "search_books",
            "description": "Search for books using their title, author or category.",
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {
                        "type": "string",
                        "description": "Book title, author or search keyword"
                    }
                },
                "required": ["keyword"],
                "additionalProperties": False
            },
            "strict": True
        }
    },

    {
        "type": "function",
        "function": {
            "name": "reserve_book",
            "description": "Reserve a book for a customer using its book ID. Use only when the customer requests a reservation.",
            "parameters": {
                "type": "object",
                "properties": {
                    "book_id": {
                        "type": "integer",
                        "description": "Unique ID of the book"
                    },
                    "customer_name": {
                        "type": "string",
                        "description": "Name of the customer"
                    }
                },
                "required": ["book_id", "customer_name"],
                "additionalProperties": False
            },
            "strict": True
        }
    }

]


# ==========================================
# STEP 3: CONNECT TO PYTHON FUNCTIONS
# ==========================================

available_functions = {

    "search_books": search_books,

    "reserve_book": reserve_book

}


# ==========================================
# STEP 4: CREATE AI AGENT
# ==========================================

def run_agent(user_message):

    messages = [

        {
            "role": "system",
            "content": """
            You are an AI Library Assistant.

            Your responsibilities:

            1. Help users search for books.
            2. Help users reserve books.
            3. Always use Python tools for book searches.
            4. Never invent book details or availability.
            5. Before reserving a book, make sure you know
               the exact book ID and customer name.
            6. If the user gives a book title instead of
               an ID, first call search_books.
            7. After getting the book ID, call reserve_book.
            8. If no copies are available, explain that
               the book cannot be reserved.
            9. Never claim a reservation succeeded unless
               the Python tool confirms success.
            10. Explain the final result clearly.
            """
        },

        {
            "role": "user",
            "content": user_message
        }

    ]


    # ==========================================
    # STEP 5: LET AI SELECT AND EXECUTE TOOLS
    # ==========================================

    for _ in range(5):

        response = client.chat.completions.create(

            model="gpt-4o-mini",

            messages=messages,

            tools=tools,

            tool_choice="auto"

        )

        assistant_message = response.choices[0].message


        # Check whether AI selected any tool

        if not assistant_message.tool_calls:

            return assistant_message.content


        # Add AI response to conversation

        messages.append(assistant_message)


        # Execute selected tools

        for tool_call in assistant_message.tool_calls:

            function_name = tool_call.function.name

            arguments = json.loads(
                tool_call.function.arguments
            )


            print("\n================================")
            print("AI SELECTED TOOL:", function_name)
            print("TOOL ARGUMENTS:", arguments)
            print("================================")


            # Get the corresponding Python function

            function_to_call = available_functions[function_name]


            # Execute the Python function

            tool_result = function_to_call(**arguments)


            print("\nTOOL RESULT:", tool_result)


            # Send result back to AI

            messages.append({

                "role": "tool",

                "tool_call_id": tool_call.id,

                "content": json.dumps(tool_result)

            })


    return "Unable to complete the request. Please try again."


# ==========================================
# STEP 6: MAIN APPLICATION
# ==========================================

if __name__ == "__main__":

    print("\n========================================")
    print("          AI LIBRARY ASSISTANT")
    print("========================================")

    print("\nWelcome to the AI Library Assistant!")

    print("\nYou can:")
    print("1. Search for books")
    print("2. Check book availability")
    print("3. Reserve books")

    print("\nType 'exit' to stop the application.")


    while True:

        user_input = input("\nYou: ").strip()


        if user_input.lower() == "exit":

            print("\nThank you for using AI Library Assistant!")

            break


        if not user_input:

            continue


        try:

            answer = run_agent(user_input)

            print("\nAI Assistant:", answer)


        except Exception as error:

            print("\nError:", error)
