import { useAuth } from "../context/AuthContext";
import { Navigate, useNavigate } from "react-router-dom";

function Payment({ cart }) {
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();

  if (cart.length === 0) {
    return <Navigate to="/" />;
  }

  if (!isLoggedIn) {
    return <Navigate to="/login" />;
  }

  const handlePayment = () => {
    navigate("/success");
  };

  return (
    <div>
      <h1>Payment Page</h1>

      <h3>Total Items: {cart.length}</h3>

      <button onClick={handlePayment}>
        Pay Now
      </button>
    </div>
  );
}

export default Payment;