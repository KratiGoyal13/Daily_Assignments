import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Home({ cart, setCart }) {
  const navigate = useNavigate();

  const [search, setSearch] = useState("");

 const products = [
  {
    id: 1,
    name: "Laptop",
    price: 50000,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500",
  },
  {
    id: 2,
    name: "Mobile",
    price: 25000,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500",
  },
  {
    id: 3,
    name: "Headphones",
    price: 2000,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500",
  },
  {
    id: 4,
    name: "Smart Watch",
    price: 5000,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500",
  },
  {
    id: 5,
    name: "Camera",
    price: 35000,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500",
  },
  {
    id: 6,
    name: "Tablet",
    price: 20000,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500",
  },
  {
    id: 7,
    name: "Gaming Mouse",
    price: 1500,
    image: "https://images.unsplash.com/photo-1527814050087-3793815479db?w=500",
  },
  {
    id: 8,
    name: "Keyboard",
    price: 3000,
    image: "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=500",
  },
  {
    id: 9,
    name: "Bluetooth Speaker",
    price: 4000,
    image: "https://images.unsplash.com/photo-1589003077984-894e133dabab?w=500",
  },
  {
    id: 10,
    name: "Monitor",
    price: 12000,
    image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=500",
  },
];

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (product) => {
    setCart([...cart, product]);
    alert(`${product.name} added to cart`);
  };

  const proceedToPayment = () => {
    if (cart.length === 0) {
      alert("Please add at least one product to cart");
      return;
    }

    navigate("/payment");
  };

  return (
    <div>
      {/* Navbar */}
      <div className="navbar">
        <h2>Amazon Clone</h2>
        <h3>🛒 Cart ({cart.length})</h3>
      </div>

      {/* Hero Section */}
      <div className="hero">
        <h1>Welcome to Amazon Clone</h1>
        <p>Shop your favourite products at the best prices</p>
      </div>

      {/* Search Box */}
      <div className="search-box">
        <input
          type="text"
          placeholder="Search Product..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Product Title */}
      <h2 className="title">Featured Products</h2>

      {/* Product Cards */}
      <div className="products">
        {filteredProducts.map((item) => (
          <div className="card" key={item.id}>
            <img
              src={item.image}
              alt={item.name}
            />

            <h3>{item.name}</h3>

            <p>₹{item.price}</p>

            <button onClick={() => addToCart(item)}>
              Add To Cart
            </button>
          </div>
        ))}
      </div>

      {/* Cart Section */}
      <div className="cart-section">
        <h3>Cart Items: {cart.length}</h3>

        <button onClick={proceedToPayment}>
          Proceed To Payment
        </button>
      </div>
    </div>
  );
}

export default Home;