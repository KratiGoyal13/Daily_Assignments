import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import "./App.css";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Payment from "./pages/Payment";
import Success from "./pages/Success";
import NotFound from "./pages/NotFound";

function App() {
  const [cart, setCart] = useState([]);

  return (
    <Routes>
      <Route
        path="/"
        element={
          <Home
            cart={cart}
            setCart={setCart}
          />
        }
      />

      <Route
        path="/login"
        element={<Login />}
      />

      <Route
        path="/payment"
        element={<Payment cart={cart} />}
      />

      <Route
        path="/success"
        element={<Success />}
      />

      <Route
        path="*"
        element={<NotFound />}
      />
    </Routes>
  );
}

export default App;