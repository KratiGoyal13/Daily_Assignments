
from agent_framework import Agent, tool
from agent_framework.openai import OpenAIChatClient

from dotenv import load_dotenv
import os

from tools import search_products, calculate_order_total


# Load environment variables
load_dotenv()


# Initialize OpenAI client
client = OpenAIChatClient(
    model=os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")
)


# ============================================================
# TOOL WRAPPERS
# ============================================================

@tool(approval_mode="never_require")
def inventory_search(search_term: str) -> str:
    """
    Search the product dataset using a product name or category.
    Returns product details, prices, ratings and stock.
    """
    return search_products(search_term)


@tool(approval_mode="never_require")
def pricing_calculator(product_id: str, quantity: int) -> str:
    """
    Calculate the total order price for a product ID and quantity.
    Also verifies stock availability.
    """
    return calculate_order_total(product_id, quantity)


# ============================================================
# AGENT 1: INVENTORY AGENT
# ============================================================

inventory_agent = Agent(
    client=client,
    name="InventoryAgent",

    instructions="""
    You are an E-commerce Inventory Specialist.

    Your responsibilities:

    1. Understand the customer's product requirements.
    2. Identify the requested product category or product name.
    3. Extract the requested quantity and total budget.
    4. ALWAYS use the inventory_search tool to search the dataset.
    5. Display matching products with:
       - Product ID
       - Product name
       - Category
       - Unit price
       - Available stock
       - Customer rating
    6. Clearly identify unavailable products with zero stock.
    7. Do not invent products or product information.
    8. Pass all relevant information to the Pricing Agent.

    IMPORTANT:
    Do not calculate order totals yourself.
    Use only information returned by the inventory tool.
    """,

    tools=[inventory_search]
)


# ============================================================
# AGENT 2: PRICING AGENT
# ============================================================

pricing_agent = Agent(
    client=client,
    name="PricingAgent",

    instructions="""
    You are an E-commerce Pricing Specialist.

    You receive the original customer request and the
    Inventory Agent's results.

    Your responsibilities:

    1. Identify the requested quantity and total budget.
    2. Review all matching products from the Inventory Agent.
    3. Ignore products with zero stock.
    4. For EACH matching product with sufficient stock,
       ALWAYS call the pricing_calculator tool.
    5. Pass the correct product ID and requested quantity.
    6. Reject products with insufficient stock.
    7. Compare the calculated total with the customer's
       total budget.
    8. Mark products as AFFORDABLE or OVER BUDGET.
    9. Display:
       - Product ID
       - Product name
       - Requested quantity
       - Available stock
       - Calculated total cost
       - Budget validation
    10. Pass all eligible products to the Recommendation Agent.

    IMPORTANT:
    Never invent prices or calculate totals from assumptions.
    Use the pricing_calculator tool results.
    A product is eligible only if sufficient stock exists
    AND its total cost is within the customer's budget.
    """,

    tools=[pricing_calculator]
)


# ============================================================
# AGENT 3: RECOMMENDATION AGENT
# ============================================================

recommendation_agent = Agent(
    client=client,
    name="RecommendationAgent",

    instructions="""
    You are an E-commerce Product Recommendation Specialist.

    You receive the original customer request, inventory
    results and pricing results.

    Your responsibilities:

    1. Review the pricing and inventory results.
    2. Consider only products that:
       - Have sufficient stock.
       - Are within the customer's total budget.
       - Have valid calculated prices.
    3. Recommend the product with the HIGHEST customer rating.
    4. If multiple products have equal ratings,
       prefer the product with the LOWER total cost.
    5. Never recommend unavailable products.
    6. Never exceed the customer's budget.
    7. If no product qualifies, clearly explain that
       no suitable product is available.

    FINAL RESPONSE FORMAT:

    E-COMMERCE SHOPPING RECOMMENDATION

    Recommended Product:
    Product ID:
    Product Name:
    Category:
    Unit Price:
    Requested Quantity:
    Total Cost:
    Customer Rating:
    Stock Availability:

    Reason for Recommendation:

    Budget Status:

    Keep the recommendation clear and concise.
    Never invent product details or prices.
    """
)


# ============================================================
# AGENT INITIALIZATION TEST
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("E-COMMERCE MULTI-AGENT SYSTEM")
    print("=" * 60)

    print("\nInventory Agent:", inventory_agent.name)
    print("Pricing Agent:", pricing_agent.name)
    print("Recommendation Agent:", recommendation_agent.name)

    print("\nAll three agents initialized successfully!")
