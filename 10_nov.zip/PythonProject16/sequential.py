
import asyncio

from agent_framework import AgentResponseUpdate
from agent_framework.orchestrations import SequentialBuilder

from agents import (
    inventory_agent,
    pricing_agent,
    recommendation_agent
)


# Build the sequential workflow
workflow = SequentialBuilder(
    participants=[
        inventory_agent,
        pricing_agent,
        recommendation_agent
    ],
    intermediate_output_from=[
        inventory_agent,
        pricing_agent
    ]
).build()


async def run_shopping_assistant(user_request):

    print("\n" + "=" * 70)
    print("E-COMMERCE AI SHOPPING ASSISTANT")
    print("=" * 70)

    print("\nCustomer Request:")
    print(user_request)

    print("\nStarting Sequential Workflow...")

    try:
        async for event in workflow.run(
            user_request,
            stream=True
        ):

            if event.type in ("intermediate", "output"):

                if isinstance(event.data, AgentResponseUpdate):

                    update = event.data

                    print("\n" + "-" * 70)
                    print(
                        f"{event.type.upper()} - "
                        f"{update.author_name}"
                    )
                    print("-" * 70)

                    print(update.text, end="", flush=True)

        print("\n\nWorkflow execution completed!")

    except Exception as error:
        print("\nWorkflow execution failed!")
        print("Error:", error)


async def main():

    print("=" * 70)
    print("MULTI-AGENT E-COMMERCE SHOPPING ASSISTANT")
    print("=" * 70)

    print("\nEnter your shopping requirement.")
    print("Example: Recommend 2 laptops within Rs.120000 total.")

    user_request = input("\nYour request: ").strip()

    if not user_request:
        print("Please enter a valid shopping request.")
        return

    await run_shopping_assistant(user_request)


if __name__ == "__main__":
    asyncio.run(main())
