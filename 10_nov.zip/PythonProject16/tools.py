
import json
from pathlib import Path


# Load products from products.json
PRODUCTS_FILE = Path(__file__).parent / "products.json"


def load_products():
    """Load product information from the JSON dataset."""

    try:
        with open(PRODUCTS_FILE, "r", encoding="utf-8") as file:
            products = json.load(file)

        if not isinstance(products, list):
            raise ValueError("products.json must contain a list.")

        return products

    except FileNotFoundError:
        raise FileNotFoundError(
            "products.json was not found in the project folder."
        )


# TOOL 1: SEARCH PRODUCTS
def search_products(search_term: str) -> str:
    """
    Search products by product name or category.

    Returns product ID, name, category, price, stock and rating.
    """

    if not isinstance(search_term, str) or not search_term.strip():
        return "Invalid search. Please provide a product name or category."

    products = load_products()

    search_term = search_term.strip().lower()

    matching_products = [
        product for product in products
        if search_term in product["name"].lower()
        or search_term in product["category"].lower()
    ]

    if not matching_products:
        return f"No products found matching '{search_term}'."

    results = []

    for product in matching_products:
        results.append(
            f"Product ID: {product['id']}\n"
            f"Name: {product['name']}\n"
            f"Category: {product['category']}\n"
            f"Price: Rs. {product['price_inr']}\n"
            f"Available Stock: {product['stock']}\n"
            f"Customer Rating: {product['rating']}/5"
        )

    return "\n\n".join(results)


# TOOL 2: CALCULATE ORDER TOTAL
def calculate_order_total(product_id: str, quantity: int) -> str:
    """
    Calculate the total price for a product.

    Validates product ID, quantity and available stock.
    """

    if not isinstance(product_id, str) or not product_id.strip():
        return "Invalid product ID."

    if isinstance(quantity, bool) or not isinstance(quantity, int):
        return "Invalid quantity. Quantity must be a whole number."

    if quantity <= 0:
        return "Invalid quantity. Quantity must be greater than zero."

    products = load_products()

    product = next(
        (
            item for item in products
            if item["id"].lower() == product_id.strip().lower()
        ),
        None
    )

    if product is None:
        return f"Product ID '{product_id}' does not exist."

    available_stock = product["stock"]

    if quantity > available_stock:
        return (
            f"INSUFFICIENT STOCK!\n"
            f"Product: {product['name']}\n"
            f"Requested Quantity: {quantity}\n"
            f"Available Stock: {available_stock}\n"
            f"Order cannot be processed."
        )

    unit_price = product["price_inr"]
    total_cost = unit_price * quantity

    return (
        f"ORDER CALCULATION SUCCESSFUL\n"
        f"Product ID: {product['id']}\n"
        f"Product Name: {product['name']}\n"
        f"Unit Price: Rs. {unit_price}\n"
        f"Quantity: {quantity}\n"
        f"Available Stock: {available_stock}\n"
        f"Total Cost: Rs. {total_cost}\n"
        f"Stock Status: Available"
    )


# INDEPENDENT TOOL TESTING
if __name__ == "__main__":

    print("=" * 60)
    print("TESTING TOOL 1: SEARCH PRODUCTS")
    print("=" * 60)

    print(search_products("Laptop"))

    print("\n" + "=" * 60)
    print("TESTING TOOL 2: CALCULATE ORDER TOTAL")
    print("=" * 60)

    print(calculate_order_total("P101", 2))

    print("\n" + "=" * 60)
    print("TESTING INSUFFICIENT STOCK")
    print("=" * 60)

    print(calculate_order_total("P102", 10))

    print("\n" + "=" * 60)
    print("TESTING INVALID PRODUCT")
    print("=" * 60)

    print(calculate_order_total("P999", 2))

    print("\n" + "=" * 60)
    print("TESTING INVALID QUANTITY")
    print("=" * 60)

    print(calculate_order_total("P101", 0))

    print("\n" + "=" * 60)
    print("TESTING NON-EXISTENT CATEGORY")
    print("=" * 60)

    print(search_products("Smartwatch"))
