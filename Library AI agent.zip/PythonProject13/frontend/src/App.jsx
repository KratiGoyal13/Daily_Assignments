
import { useState, useEffect, useRef } from "react";
import "./App.css";

// Sample library books
const initialBooks = [
  {
    id: 101,
    title: "Python Crash Course",
    author: "Eric Matthes",
    category: "Programming",
    available_copies: 3,
  },
  {
    id: 102,
    title: "Automate the Boring Stuff with Python",
    author: "Al Sweigart",
    category: "Programming",
    available_copies: 2,
  },
  {
    id: 103,
    title: "Hands-On Machine Learning",
    author: "Aurélien Géron",
    category: "Artificial Intelligence",
    available_copies: 2,
  },
  {
    id: 104,
    title: "Deep Learning",
    author: "Ian Goodfellow",
    category: "Artificial Intelligence",
    available_copies: 0,
  },
  {
    id: 105,
    title: "The Alchemist",
    author: "Paulo Coelho",
    category: "Fiction",
    available_copies: 4,
  },
];

function App() {
  const [books, setBooks] = useState(initialBooks);

  const [messages, setMessages] = useState([
    {
      type: "bot",
      text: "Hello! Welcome to AI Library Assistant. I can help you search for books, check availability and reserve available copies. How can I help you today?",
    },
  ]);

  const [input, setInput] = useState("");
  const [pendingReservation, setPendingReservation] = useState(null);
  const [reservations, setReservations] = useState([]);
  const [isTyping, setIsTyping] = useState(false);

  const chatEndRef = useRef(null);

  // Scroll to latest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, isTyping]);

  // Add bot message
  const addBotMessage = (text, tool = null, extra = null) => {
    setMessages((previous) => [
      ...previous,
      {
        type: "bot",
        text,
        tool,
        extra,
      },
    ]);
  };

  // Search books
  const searchBooks = (keyword) => {
    const normalizedKeyword = keyword.toLowerCase().trim();

    const words = normalizedKeyword
      .split(/\s+/)
      .filter((word) => word.length > 0);

    const results = books.filter((book) => {
      const searchableText =
        `${book.title} ${book.author} ${book.category}`.toLowerCase();

      return words.some((word) =>
        searchableText.includes(word)
      );
    });

    if (results.length === 0) {
      addBotMessage(
        `Sorry! I couldn't find any books matching "${keyword}". Please try another keyword.`,
        "search_books"
      );

      return;
    }

    addBotMessage(
      `I found ${results.length} matching book(s) in our library:`,
      "search_books",
      {
        books: results,
      }
    );
  };

  // Process user messages
  const processMessage = (message) => {
    const lower = message.toLowerCase().trim();

    // 1. Greetings
    if (
      ["hi", "hello", "hey", "thanks", "thank you"].includes(lower)
    ) {
      addBotMessage(
        "Hello! I can help you search for books, check availability and reserve books. Try searching for Python or Artificial Intelligence."
      );

      return;
    }

    // 2. Show all books
    if (
      ["books", "show all books", "list all books"].includes(lower)
    ) {
      addBotMessage(
        `Here are all ${books.length} books in our library:`,
        "search_books",
        {
          books: books,
        }
      );

      return;
    }

    // 3. Handle reservation
    if (lower.includes("reserve")) {
      const requestedBook = books.find((book) => {
        return (
          lower.includes(book.title.toLowerCase()) ||
          new RegExp(`\\b${book.id}\\b`).test(lower)
        );
      });

      if (!requestedBook) {
        addBotMessage(
          "I couldn't identify the requested book. Please enter its exact title or book ID."
        );

        return;
      }

      // Extract customer name
      const customerMatch = message.match(
        /\bfor\s+(.+?)\s*[.!?]*$/i
      );

      const customerName = customerMatch
        ? customerMatch[1].trim()
        : "";

      if (!customerName) {
        addBotMessage(
          "Please provide the customer's name. Example: Reserve Python Crash Course for Ahmed."
        );

        return;
      }

      // Check availability
      if (requestedBook.available_copies <= 0) {
        addBotMessage(
          `Sorry! "${requestedBook.title}" is currently unavailable. There are no available copies.`,
          "reserve_book"
        );

        return;
      }

      // Ask for confirmation
      setPendingReservation({
        bookId: requestedBook.id,
        customerName: customerName,
      });

      addBotMessage(
        `Good news! "${requestedBook.title}" is available. Would you like to confirm the reservation for ${customerName}?`,
        "reserve_book",
        {
          confirmation: true,
        }
      );

      return;
    }

    // 4. Handle book searches and availability questions

    let keyword = lower
      .replace(/find books related to/gi, "")
      .replace(/find books/gi, "")
      .replace(/find me books/gi, "")
      .replace(/search books related to/gi, "")
      .replace(/search books for/gi, "")
      .replace(/search for/gi, "")
      .replace(/search/gi, "")
      .replace(/show me books related to/gi, "")
      .replace(/show me books/gi, "")
      .replace(/show books/gi, "")
      .replace(/show me/gi, "")
      .replace(/show/gi, "")
      .replace(/find/gi, "")
      .replace(/^is\s+/i, "")
      .replace(/\s+available\??$/i, "")
      .replace(/\s+in the library\??$/i, "")
      .replace(/[?.!]/g, "")
      .trim();

    // Remove unnecessary words from availability questions
    keyword = keyword
      .replace(/^the\s+/i, "")
      .replace(/^book\s+/i, "")
      .trim();

    const ignoredMessages = [
      "",
      "ok",
      "okay",
      "ok plz",
      "yes",
      "no",
      "plz",
      "please",
    ];

    if (!ignoredMessages.includes(keyword)) {
      searchBooks(keyword);
      return;
    }

    // 5. Default response
    addBotMessage(
      "I can help you search for books and reserve available copies. Try: Find books related to Python programming."
    );
  };

  // Send user message
  const handleSend = () => {
    const message = input.trim();

    if (!message || pendingReservation || isTyping) {
      return;
    }

    setMessages((previous) => [
      ...previous,
      {
        type: "user",
        text: message,
      },
    ]);

    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      processMessage(message);
      setIsTyping(false);
    }, 500);
  };

  // Confirm reservation
  const confirmReservation = () => {
    if (!pendingReservation) {
      return;
    }

    const { bookId, customerName } = pendingReservation;

    const selectedBook = books.find(
      (book) => book.id === bookId
    );

    if (!selectedBook || selectedBook.available_copies <= 0) {
      setPendingReservation(null);

      addBotMessage(
        "Sorry! This book is no longer available."
      );

      return;
    }

    // Create reservation
    const reservation = {
      reservation_id: reservations.length + 1,
      book_id: selectedBook.id,
      book_title: selectedBook.title,
      customer_name: customerName,
      reservation_date: new Date().toLocaleString(),
    };

    setReservations((previous) => [
      ...previous,
      reservation,
    ]);

    // Reduce available copies
    setBooks((previous) =>
      previous.map((book) =>
        book.id === bookId
          ? {
              ...book,
              available_copies: book.available_copies - 1,
            }
          : book
      )
    );

    setPendingReservation(null);

    addBotMessage(
      `Reservation successful! "${selectedBook.title}" has been reserved for ${customerName}. Remaining copies: ${selectedBook.available_copies - 1}.`,
      "reservation_success"
    );
  };

  // Cancel reservation
  const cancelReservation = () => {
    setPendingReservation(null);

    addBotMessage(
      "Your reservation request has been cancelled successfully. No changes were made to book availability.",
      "reservation_cancelled"
    );
  };

  // Handle Enter key
  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSend();
    }
  };

  // Clear chat
  const clearChat = () => {
    setMessages([
      {
        type: "bot",
        text: "Hello! Welcome to AI Library Assistant. I can help you search for books, check availability and reserve available copies. How can I help you today?",
      },
    ]);

    setPendingReservation(null);
    setInput("");
  };

  return (
    <div className="app-container">
      <div className="chat-card">

        {/* HEADER */}
        <header className="chat-header">
          <div className="brand-icon">
            <span>▤</span>
          </div>

          <div className="header-info">
            <h2>AI Library Assistant</h2>
            <p>Book Search & Reservations</p>
          </div>

          <button
            className="clear-button"
            onClick={clearChat}
            title="Clear chat"
          >
            ↻
          </button>
        </header>

        {/* CHAT MESSAGES */}
        <main className="chat-messages">

          {messages.map((message, index) => (
            <div
              key={index}
              className={`message-row ${message.type}`}
            >

              {message.type === "bot" && (
                <div className="bot-avatar">
                  ▣
                </div>
              )}

              <div className="message-content">

                <div className="message-bubble">
                  {message.text}
                </div>

                {/* BOOK SEARCH RESULTS */}
                {message.extra?.books && (
                  <div className="book-results">

                    {message.extra.books.map((book) => (
                      <div
                        className="book-item"
                        key={book.id}
                      >

                        <div className="book-icon">
                          📚
                        </div>

                        <div className="book-details">
                          <h4>{book.title}</h4>

                          <p>
                            By {book.author}
                          </p>

                          <span>
                            {book.category}
                          </span>
                        </div>

                        <div
                          className={`availability ${
                            book.available_copies === 0
                              ? "unavailable"
                              : ""
                          }`}
                        >
                          {book.available_copies > 0
                            ? `${book.available_copies} copies available`
                            : "Out of stock"}
                        </div>

                      </div>
                    ))}

                  </div>
                )}

                {/* CONFIRMATION BUTTONS */}
                {message.extra?.confirmation &&
                  index === messages.length - 1 &&
                  pendingReservation && (
                    <div className="confirmation-buttons">

                      <button
                        className="confirm-button"
                        onClick={confirmReservation}
                      >
                        ✓ Confirm
                      </button>

                      <button
                        className="cancel-button"
                        onClick={cancelReservation}
                      >
                        ✕ Cancel
                      </button>

                    </div>
                  )}

                {/* TOOL INFORMATION */}
                {message.tool && (
                  <p className="tool-label">
                    <span className="tool-dot"></span>
                    Tool used: {message.tool}
                  </p>
                )}

              </div>
            </div>
          ))}

          {/* TYPING INDICATOR */}
          {isTyping && (
            <div className="message-row bot">

              <div className="bot-avatar">
                ▣
              </div>

              <div className="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>

            </div>
          )}

          <div ref={chatEndRef}></div>

        </main>

        {/* INPUT FOOTER */}
        <footer className="chat-footer">

          {pendingReservation && (
            <p className="pending-label">
              Please confirm or cancel your reservation above.
            </p>
          )}

          <div className="input-container">

            <input
              type="text"
              placeholder="Type your message..."
              value={input}
              onChange={(event) =>
                setInput(event.target.value)
              }
              onKeyDown={handleKeyDown}
              disabled={!!pendingReservation || isTyping}
            />

            <button
              className="send-button"
              onClick={handleSend}
              disabled={
                !input.trim() ||
                !!pendingReservation ||
                isTyping
              }
              title="Send message"
            >
              ➤
            </button>

          </div>

          <p className="footer-note">
            AI Library Assistant · Book Search & Reservations
          </p>

        </footer>

      </div>
    </div>
  );
}

export default App;
