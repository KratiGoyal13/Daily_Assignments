
import asyncio
import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Never

from dotenv import load_dotenv

from azure.identity import AzureCliCredential

from agent_framework import (
    Agent,
    Executor,
    WorkflowBuilder,
    WorkflowContext,
    handler,
    response_handler,
)

from agent_framework.foundry import FoundryChatClient


# ==========================================================
# 1. LOAD CONFIGURATION
# ==========================================================

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

ENDPOINT = os.getenv("FOUNDRY_PROJECT_ENDPOINT")
MODEL = os.getenv("FOUNDRY_MODEL")

DATA_FILE = BASE_DIR / "purchases.json"


# ==========================================================
# 2. DATA MODELS
# ==========================================================

@dataclass
class PurchaseCase:
    id: str
    item: str
    vendor: str
    vendor_status: str
    quantity: int
    amount_inr: float
    justification: str

    eligibility_findings: str = ""
    risk_level: str = "NOT_ASSESSED"
    risk_assessment: str = ""

    approval_route: str = ""
    final_decision: str = ""
    manager_decision: str = ""
    customer_message: str = ""


@dataclass
class ApprovalRequest:
    request_id: str
    item: str
    amount_inr: float
    eligibility_issues: str
    risk_assessment: str


# ==========================================================
# 3. CREATE AZURE AI FOUNDRY AGENTS
# ==========================================================

def create_agents(credential):

    client = FoundryChatClient(
        project_endpoint=ENDPOINT,
        model=MODEL,
        credential=credential,
    )

    # Agent 1: Eligibility Agent
    eligibility_agent = Agent(
        client=client,
        name="EligibilityAgent",
        instructions="""
        You are a Purchase Eligibility Agent.

        Analyze purchase requests using these rules:

        1. Vendor must have approved status.
        2. Purchase amount must be below or equal to INR 50,000.

        Explain whether the purchase satisfies these conditions.
        Identify any issues clearly.

        Do not approve purchases yourself.
        Python determines the final eligibility.
        """
    )

    # Agent 2: Risk Agent
    risk_agent = Agent(
        client=client,
        name="RiskAgent",
        instructions="""
        You are a Purchase Risk Assessment Agent.

        Analyze purchase requests for:
        1. New or unapproved vendors.
        2. Unusually high purchase amounts.
        3. Unclear purchase justifications.

        Provide a concise risk assessment.
        Identify LOW, MEDIUM or HIGH risk.

        Do not make final approval decisions.
        """
    )

    # Agent 3: Customer Response Agent
    response_agent = Agent(
        client=client,
        name="CustomerResponseAgent",
        instructions="""
        You are a Purchase Request Communication Agent.

        Prepare a professional message for the employee
        who submitted the purchase request.

        Explain the final decision accurately.

        Approved: Say that the purchase request has been approved.
        Rejected: Say that the purchase request was rejected.
        Never claim that payment has been made or goods delivered.

        Do not change or override the manager's decision.
        """
    )

    return eligibility_agent, risk_agent, response_agent


# ==========================================================
# 4. AGENT 1: ELIGIBILITY EXECUTOR
# ==========================================================

class EligibilityExecutor(Executor):

    def __init__(self, agent):
        super().__init__(id="eligibility_executor")
        self.agent = agent

    @handler
    async def check_eligibility(
        self,
        case: PurchaseCase,
        ctx: WorkflowContext[PurchaseCase]
    ):

        print("\n[Eligibility Agent] Analyzing:", case.id)

        prompt = f"""
        Analyze this purchase request:

        {json.dumps(asdict(case), indent=2)}

        Explain the eligibility findings.
        """

        response = await self.agent.run(prompt)

        case.eligibility_findings = response.text

        # Deterministic Python business rules
        issues = []

        if case.vendor_status.lower() != "approved":
            issues.append("Vendor is not approved.")

        if case.amount_inr > 50000:
            issues.append("Purchase amount exceeds INR 50,000.")

        if not case.justification.strip():
            issues.append("Purchase justification is missing.")

        if issues:
            case.eligibility_findings += (
                "\nPython policy checks: " + " ".join(issues)
            )
        else:
            case.eligibility_findings += (
                "\nPython policy checks: All conditions satisfied."
            )

        print("[Eligibility Agent] Completed.")

        await ctx.send_message(case)


# ==========================================================
# 5. AGENT 2: RISK EXECUTOR
# ==========================================================

class RiskExecutor(Executor):

    def __init__(self, agent):
        super().__init__(id="risk_executor")
        self.agent = agent

    @handler
    async def assess_risk(
        self,
        case: PurchaseCase,
        ctx: WorkflowContext[PurchaseCase]
    ):

        print("\n[Risk Agent] Analyzing:", case.id)

        prompt = f"""
        Assess the risk of this purchase request:

        {json.dumps(asdict(case), indent=2)}

        Provide a concise risk assessment.
        """

        response = await self.agent.run(prompt)

        case.risk_assessment = response.text

        # Deterministic risk checks
        if (
            case.vendor_status.lower() != "approved"
            or case.amount_inr >= 100000
        ):
            case.risk_level = "HIGH"

        elif case.amount_inr >= 25000:
            case.risk_level = "MEDIUM"

        else:
            case.risk_level = "LOW"

        case.risk_assessment += (
            f"\nPython risk classification: {case.risk_level}"
        )

        print("[Risk Agent] Risk:", case.risk_level)

        await ctx.send_message(case)


# ==========================================================
# 6. APPROVAL GATEWAY + HUMAN IN THE LOOP
# ==========================================================

class ApprovalGateway(Executor):

    def __init__(self):
        super().__init__(id="approval_gateway")

    @handler
    async def route_request(
        self,
        case: PurchaseCase,
        ctx: WorkflowContext[PurchaseCase]
    ):

        print("\n[Approval Gateway] Checking approval conditions.")

        eligible = (
            case.vendor_status.lower() == "approved"
            and case.amount_inr <= 50000
            and bool(case.justification.strip())
        )

        low_risk = case.risk_level != "HIGH"

        # Automatic approval
        if eligible and low_risk:

            case.approval_route = "Automatic"
            case.final_decision = "AUTO_APPROVED"

            print("[Gateway] Automatic approval:", case.id)

            await ctx.send_message(case)

        # Human review required
        else:

            case.approval_route = "Human Review"

            print("\n[Gateway] Manager approval required.")

            approval_request = ApprovalRequest(
                request_id=case.id,
                item=case.item,
                amount_inr=case.amount_inr,
                eligibility_issues=case.eligibility_findings,
                risk_assessment=case.risk_assessment,
            )

            # Pause the workflow and wait for manager input
            await ctx.request_info(
                request_data=approval_request,
                response_type=str,
                request_id=f"approval-{case.id}",
            )

    @response_handler
    async def handle_manager_response(
        self,
        original_request: ApprovalRequest,
        response: str,
        ctx: WorkflowContext[PurchaseCase],
    ):

        decision = response.strip().lower()

        if decision not in ("approve", "reject"):
            raise ValueError("Invalid manager decision.")

        print("\n[Gateway] Manager decision:", decision.upper())

        # Preserve the decision without allowing AI to override it
        if decision == "approve":
            final_decision = "MANAGER_APPROVED"
        else:
            final_decision = "MANAGER_REJECTED"

        # Reconstruct the case context from the pending request.
        # The full case is attached to the request in the workflow
        # implementation below through the executor's context map.
        case = self.pending_cases[original_request.request_id]

        case.manager_decision = decision.upper()
        case.final_decision = final_decision

        await ctx.send_message(case)

    def remember_case(self, case):
        if not hasattr(self, "pending_cases"):
            self.pending_cases = {}

        self.pending_cases[case.id] = case


# ==========================================================
# 7. AGENT 3: CUSTOMER RESPONSE EXECUTOR
# ==========================================================

class CustomerResponseExecutor(Executor):

    def __init__(self, agent):
        super().__init__(id="customer_response_executor")
        self.agent = agent

    @handler
    async def generate_response(
        self,
        case: PurchaseCase,
        ctx: WorkflowContext[Never, dict]
    ):

        print("\n[Customer Response Agent] Preparing message.")

        prompt = f"""
        Prepare a professional purchase request notification.

        Request ID: {case.id}
        Item: {case.item}
        Amount: INR {case.amount_inr}
        Final decision: {case.final_decision}
        Approval route: {case.approval_route}
        Manager decision: {case.manager_decision}

        Prepare a short, accurate notification.
        Do not claim that payment or delivery has happened.
        Do not change the final decision.
        """

        response = await self.agent.run(prompt)

        case.customer_message = response.text

        # Protect the decision from AI-generated changes
        if case.final_decision == "MANAGER_REJECTED":
            case.customer_message = (
                f"Your purchase request {case.id} for {case.item} "
                "has been rejected by the manager. "
                "Please contact the procurement team for further information."
            )

        elif case.final_decision == "MANAGER_APPROVED":
            case.customer_message = (
                f"Your purchase request {case.id} for {case.item} "
                "has been approved by the manager. "
                "This approval does not mean payment or delivery is complete."
            )

        elif case.final_decision == "AUTO_APPROVED":
            case.customer_message = (
                f"Your purchase request {case.id} for {case.item} "
                "has been automatically approved under the demonstration policy. "
                "This approval does not mean payment or delivery is complete."
            )

        final_output = asdict(case)

        print("[Customer Response Agent] Completed.")

        await ctx.yield_output(final_output)


# ==========================================================
# 8. BUILD GRAPH WORKFLOW
# ==========================================================

def build_workflow(agents):

    eligibility_agent, risk_agent, response_agent = agents

    eligibility = EligibilityExecutor(eligibility_agent)
    risk = RiskExecutor(risk_agent)
    gateway = ApprovalGateway()
    customer_response = CustomerResponseExecutor(response_agent)

    workflow = (
        WorkflowBuilder(start_executor=eligibility)
        .add_edge(eligibility, risk)
        .add_edge(risk, gateway)
        .add_edge(gateway, customer_response)
        .build()
    )

    return workflow, gateway


# ==========================================================
# 9. LOAD PURCHASE REQUESTS
# ==========================================================

def load_requests():

    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found: {DATA_FILE}"
        )

    with open(DATA_FILE, "r", encoding="utf-8") as file:
        records = json.load(file)

    if not isinstance(records, list):
        raise ValueError("JSON must contain a list of purchase requests.")

    cases = []

    for record in records:

        case = PurchaseCase(
            id=record["id"],
            item=record["item"],
            vendor=record["vendor"],
            vendor_status=record["vendor_status"],
            quantity=int(record["quantity"]),
            amount_inr=float(record["amount_inr"]),
            justification=record["justification"],
        )

        cases.append(case)

    return cases


# ==========================================================
# 10. MANAGER INPUT VALIDATION
# ==========================================================

def get_manager_decision(request):

    print("\n" + "=" * 60)
    print("HUMAN-IN-THE-LOOP: MANAGER REVIEW")
    print("=" * 60)

    print("Request ID:", request.request_id)
    print("Item:", request.item)
    print("Amount: INR", request.amount_inr)

    print("\nEligibility findings:")
    print(request.eligibility_issues)

    print("\nRisk assessment:")
    print(request.risk_assessment)

    while True:

        decision = input(
            "\nManager decision (approve/reject): "
        ).strip().lower()

        if decision in ("approve", "reject"):
            return decision

        print("Invalid input! Enter only approve or reject.")


# ==========================================================
# 11. RUN WORKFLOW AND RESUME AFTER HUMAN INPUT
# ==========================================================

async def process_case(case, agents):

    workflow, gateway = build_workflow(agents)

    gateway.remember_case(case)

    print("\n" + "#" * 65)
    print("PROCESSING PURCHASE REQUEST:", case.id)
    print("#" * 65)

    stream = workflow.run(case, stream=True)

    final_output = None
    pending_responses = {}

    while True:

        async for event in stream:

            if event.type == "request_info":

                request = event.data

                decision = get_manager_decision(request)

                pending_responses[event.request_id] = decision

            elif event.type == "output":

                final_output = event.data

        if not pending_responses:
            break

        print("\n[Workflow] Resuming paused workflow...")

        stream = workflow.run(
            stream=True,
            responses=pending_responses,
        )

        pending_responses = {}

    if final_output:

        print("\nFINAL RESULT")
        print(json.dumps(final_output, indent=4, ensure_ascii=False))

    return final_output


# ==========================================================
# 12. MAIN APPLICATION
# ==========================================================

async def main():

    print("=" * 65)
    print("E-COMMERCE RETURNS ASSESSMENT")
    print("ADAPTED DEMONSTRATION: PURCHASE REQUEST PROCESSING")
    print("=" * 65)

    # Check missing Azure configuration
    if not ENDPOINT or not MODEL:

        print("\nCONFIGURATION ERROR")
        print("Please configure FOUNDRY_PROJECT_ENDPOINT and FOUNDRY_MODEL.")
        return

    try:

        cases = load_requests()

        print(f"\nLoaded {len(cases)} purchase requests.")

        credential = AzureCliCredential()

        agents = create_agents(credential)

        results = []

        for case in cases:

            result = await process_case(case, agents)

            if result:
                results.append(result)

        # Save all results
        output_file = BASE_DIR / "final_results.json"

        with open(output_file, "w", encoding="utf-8") as file:
            json.dump(
                results,
                file,
                indent=4,
                ensure_ascii=False,
            )

        print("\n" + "=" * 65)
        print("ALL PURCHASE REQUESTS PROCESSED")
        print("=" * 65)

        for result in results:
            print(
                result["id"],
                "->",
                result["final_decision"],
            )

        print("\nResults saved to:", output_file)

    except Exception as error:

        print("\nAPPLICATION ERROR")
        print(str(error))

        print(
            "\nCheck Azure configuration, authentication, "
            "model deployment and input data."
        )


if __name__ == "__main__":
    asyncio.run(main())
